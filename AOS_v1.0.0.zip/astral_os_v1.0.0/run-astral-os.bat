@echo off
setlocal

cd /d "%~dp0"

echo Starting Astral OS...
powershell -ExecutionPolicy Bypass -File ".\run-qemu.ps1"

if errorlevel 1 (
    echo.
    echo Astral OS could not start.
    echo Make sure QEMU is installed on this PC.
    pause
    exit /b 1
)
