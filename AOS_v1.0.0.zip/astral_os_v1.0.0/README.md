# Astral OS Shareable Build

This folder contains a current shareable Astral OS build.

## Quick Start

1. Install QEMU for Windows if it is not already installed.
2. Double-click `run-astral-os.bat`.

## What Is Included

- `esp/EFI/BOOT/BOOTX64.EFI`
  - the current bootable Astral OS UEFI image
- `run-astral-os.bat`
  - one-click launcher
- `run-qemu.ps1`
  - QEMU launch script
- `apps/`
  - sample ALEX1 apps included for reference

## Notes

- This is a bootable Astral OS prototype, not a finished production operating system.
- It is intended to run in QEMU on Windows.
- The script will create a local `firmware/OVMF_VARS.fd` file the first time it runs.

## Share It

You can share this whole `Astral_OS_Shareable` folder with friends as-is.
