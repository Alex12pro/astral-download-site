param(
    [switch]$Headless,
    [int]$AutoStopSeconds = 0
)

$ErrorActionPreference = "Stop"

$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$espRoot = Join-Path $bundleRoot "esp"
$varsRoot = Join-Path $bundleRoot "firmware"

if (-not (Test-Path $espRoot)) {
    throw "ESP folder not found beside this script."
}

$commonQemu = "C:\Program Files\qemu\qemu-system-x86_64.exe"
$qemu = $null
if (Test-Path $commonQemu) {
    $qemu = @{ Source = $commonQemu }
}
if (-not $qemu) {
    $qemu = Get-Command qemu-system-x86_64.exe -ErrorAction SilentlyContinue
}

if (-not $qemu) {
    throw "QEMU was not found. Install QEMU and run this again."
}

$firmwareCandidates = @(
    "C:\Program Files\qemu\share\edk2-x86_64-code.fd",
    "C:\Program Files\qemu\share\OVMF\OVMF_CODE.fd",
    "C:\Program Files\qemu\share\qemu\edk2-x86_64-code.fd"
)
$firmware = $firmwareCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $firmware) {
    throw "UEFI firmware image not found in the QEMU installation."
}

$varsCandidates = @(
    "C:\Program Files\qemu\share\edk2-i386-vars.fd",
    "C:\Program Files\qemu\share\OVMF\OVMF_VARS.fd",
    "C:\Program Files\qemu\share\qemu\OVMF_VARS.fd"
)
$varsTemplate = $varsCandidates | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $varsTemplate) {
    throw "UEFI variable store image not found in the QEMU installation."
}

New-Item -ItemType Directory -Force -Path $varsRoot | Out-Null
$varsFile = Join-Path $varsRoot "OVMF_VARS.fd"
if (-not (Test-Path $varsFile)) {
    Copy-Item $varsTemplate $varsFile -Force
}

$args = @(
    "-machine", "q35,accel=tcg",
    "-m", "512M",
    "-device", "qemu-xhci",
    "-device", "usb-tablet",
    "-drive", "if=pflash,format=raw,readonly=on,file=$firmware",
    "-drive", "if=pflash,format=raw,file=$varsFile",
    "-drive", "format=raw,file=fat:rw:$espRoot"
)

if ($Headless) {
    $args += @("-display", "none", "-serial", "stdio")
} else {
    $args += @("-display", "gtk", "-serial", "stdio")
}

if ($AutoStopSeconds -gt 0) {
    $argumentLine = ($args | ForEach-Object {
        if ($_ -match '\s') { '"' + $_ + '"' } else { $_ }
    }) -join ' '
    $process = Start-Process -FilePath $qemu.Source -ArgumentList $argumentLine -PassThru
    Start-Sleep -Seconds $AutoStopSeconds

    if (-not $process.HasExited) {
        Stop-Process -Id $process.Id
        Write-Host "Astral OS shareable smoke test completed after $AutoStopSeconds seconds."
    } else {
        throw "QEMU exited early with code $($process.ExitCode)."
    }
} else {
    & $qemu.Source @args
}
